"""Public API."""
from .core import bingo

__all__ = ["run_bingo"]
