# Bingo

A tiny, pure-Python package 

## Installation

```bash
pip install bingo
